// start the popup specefic scripts
// safe to use $
jQuery(document).ready(function($) {
    
    window.nk_tb_height = (92 / 100) * jQuery(window).height();
    window.azkaban_shortcodes_height = (71 / 100) * jQuery(window).height();
    if(window.azkaban_shortcodes_height > 550) {
        window.azkaban_shortcodes_height = (74 / 100) * jQuery(window).height();
    }

    jQuery(window).resize(function() {
        window.nk_tb_height = (92 / 100) * jQuery(window).height();
        window.azkaban_shortcodes_height = (71 / 100) * jQuery(window).height();

        if(window.azkaban_shortcodes_height > 550) {
            window.azkaban_shortcodes_height = (74 / 100) * jQuery(window).height();
        }
    });


    azkaban_shortcodes = {
    	loadVals: function()
    	{
    		var shortcode = $('#_azkaban_shortcode').text(),
    			uShortcode = shortcode;

    		// fill in the gaps eg {{param}}
    		$('.azkaban-input').each(function() {
    			var input = $(this),
    				id = input.attr('id'),
    				id = id.replace('azkaban_', ''),		// gets rid of the azkaban_ prefix
    				re = new RegExp("{{"+id+"}}","g");
                    var value = input.val();
                    if(value == null) {
                      value = '';
                    }
    			uShortcode = uShortcode.replace(re, value);
    		});

    		// adds the filled-in shortcode as hidden input
    		$('#_azkaban_ushortcode').remove();
    		$('#azkaban-sc-form-table').prepend('<div id="_azkaban_ushortcode" class="hidden">' + uShortcode + '</div>');
    	},
    	cLoadVals: function()
    	{
    		var shortcode = $('#_azkaban_cshortcode').text(),
    			pShortcode = '';

    			if(shortcode.indexOf("<li>") < 0) {
    				shortcodes = '<br />';
    			} else {
    				shortcodes = '';
    			}

    		// fill in the gaps eg {{param}}
    		$('.child-clone-row').each(function() {
    			var row = $(this),
    				rShortcode = shortcode;

                if($(this).find('#azkaban_slider_type').length >= 1) {
                    if($(this).find('#azkaban_slider_type').val() == 'image') {
                        rShortcode = '[slide type="{{slider_type}}" link="{{image_url}}" linktarget="{{image_target}}" lightbox="{{image_lightbox}}"]{{image_content}}[/slide]';
                    } else if($(this).find('#azkaban_slider_type').val() == 'video') {
                        rShortcode = '[slide type="{{slider_type}}"]{{video_content}}[/slide]';
                    }
                }
    			$('.azkaban-cinput', this).each(function() {
    				var input = $(this),
    					id = input.attr('id'),
    					id = id.replace('azkaban_', '')		// gets rid of the azkaban_ prefix
    					re = new RegExp("{{"+id+"}}","g");
                        var value = input.val();
                        if(value == null) {
                          value = '';
                        }
    				rShortcode = rShortcode.replace(re, input.val());
    			});

    			if(shortcode.indexOf("<li>") < 0) {
    				shortcodes = shortcodes + rShortcode + '<br />';
    			} else {
    				shortcodes = shortcodes + rShortcode;
    			}
    		});

    		// adds the filled-in shortcode as hidden input
    		$('#_azkaban_cshortcodes').remove();
    		$('.child-clone-rows').prepend('<div id="_azkaban_cshortcodes" class="hidden">' + shortcodes + '</div>');

    		// add to parent shortcode
    		this.loadVals();
    		pShortcode = $('#_azkaban_ushortcode').html().replace('{{child_shortcode}}', shortcodes);

    		// add updated parent shortcode
    		$('#_azkaban_ushortcode').remove();
    		$('#azkaban-sc-form-table').prepend('<div id="_azkaban_ushortcode" class="hidden">' + pShortcode + '</div>');
    	},
    	children: function()
    	{
    		// assign the cloning plugin
    		$('.child-clone-rows').appendo({
    			subSelect: '> div.child-clone-row:last-child',
    			allowDelete: false,
    			focusFirst: false,
                onAdd: function(row) {
                    // Get Upload ID
                    var prev_upload_id = jQuery(row).prev().find('.azkaban-upload-button').data('upid');
                    var new_upload_id = prev_upload_id + 1;
                    jQuery(row).find('.azkaban-upload-button').attr('data-upid', new_upload_id);

                    // activate chosen
                    jQuery('.azkaban-form-multiple-select').chosen({
                        width: '100%',
                        placeholder_text_multiple: 'Select Options or Leave Blank for All'
                    });

                    // activate color picker
                    jQuery('.wp-color-picker-field').wpColorPicker({
                        change: function(event, ui) {
                            azkaban_shortcodes.loadVals();
                            azkaban_shortcodes.cLoadVals();
                        }
                    });

                    // changing slide type
                    var type = $(row).find('#azkaban_slider_type').val();

                    if(type == 'video') {
                        $(row).find('#azkaban_image_content, #azkaban_image_url, #azkaban_image_target, #azkaban_image_lightbox').closest('li').hide();
                        $(row).find('#azkaban_video_content').closest('li').show();

                        $(row).find('#_azkaban_cshortcode').text('[slide type="{{slider_type}}"]{{video_content}}[/slide]');
                    }

                    if(type == 'image') {
                        $(row).find('#azkaban_image_content, #azkaban_image_url, #azkaban_image_target, #azkaban_image_lightbox').closest('li').show();
                        $(row).find('#azkaban_video_content').closest('li').hide();

                        $(row).find('#_azkaban_cshortcode').text('[slide type="{{slider_type}}" link="{{image_url}}" linktarget="{{image_target}}" lightbox="{{image_lightbox}}"]{{image_content}}[/slide]');
                    }

                    azkaban_shortcodes.loadVals();
                    azkaban_shortcodes.cLoadVals();
                }
    		});

    		// remove button
    		$('.child-clone-row-remove').live('click', function() {
    			var	btn = $(this),
    				row = btn.parent();

    			if( $('.child-clone-row').size() > 1 )
    			{
    				row.remove();
    			}
    			else
    			{
    				alert('You need a minimum of one row');
    			}

    			return false;
    		});

    		// assign jUI sortable
    		$( ".child-clone-rows" ).sortable({
				placeholder: "sortable-placeholder",
				items: '.child-clone-row',
                cancel: 'div.iconpicker, input, select, textarea, a'
			});
    	},
    	resizeTB: function()
    	{
			var	ajaxCont = $('#TB_ajaxContent'),
				tbWindow = $('#TB_window'),
				azkabanPopup = $('#azkaban-popup');

            tbWindow.css({
                height: window.nk_tb_height,
                width: azkabanPopup.outerWidth(),
                marginLeft: -(azkabanPopup.outerWidth()/2)
            });

			ajaxCont.css({
				paddingTop: 0,
				paddingLeft: 0,
				paddingRight: 0,
				height: window.nk_tb_height,
				overflow: 'auto', // IMPORTANT
				width: azkabanPopup.outerWidth()
			});

            tbWindow.show();

			$('#azkaban-popup').addClass('no_preview');
            $('#azkaban-sc-form-wrap #azkaban-sc-form').height(window.azkaban_shortcodes_height);
    	},
    	load: function()
    	{
    		var	azkaban = this,
    			popup = $('#azkaban-popup'),
    			form = $('#azkaban-sc-form', popup),
    			shortcode = $('#_azkaban_shortcode', form).text(),
    			popupType = $('#_azkaban_popup', form).text(),
    			uShortcode = '';

            // if its the shortcode selection popup
            if($('#_azkaban_popup').text() == 'shortcode-generator') {
                $('.azkaban-sc-form-button').hide();
            }

    		// resize TB
    		azkaban_shortcodes.resizeTB();
    		$(window).resize(function() { azkaban_shortcodes.resizeTB() });

    		// initialise
            azkaban_shortcodes.loadVals();
    		azkaban_shortcodes.children();
    		azkaban_shortcodes.cLoadVals();

    		// update on children value change
    		$('.azkaban-cinput', form).live('change', function() {
    			azkaban_shortcodes.cLoadVals();
    		});

    		// update on value change
    		$('.azkaban-input', form).live('change', function() {
    			azkaban_shortcodes.loadVals();
    		});

            // change shortcode when a user selects a shortcode from choose a dropdown field
            $('#azkaban_select_shortcode').change(function() {
                var name = $(this).val();
                var label = $(this).text();

                if(name != 'select') {
                    tinyMCE.activeEditor.execCommand("azkabanPopup", false, {
                        title: label,
                        identifier: name
                    });

                    $('#TB_window').hide();
                }
            });

            // activate chosen
            $('.azkaban-form-multiple-select').chosen({
                width: '100%',
                placeholder_text_multiple: 'Select Options'
            });

            // update upload button ID
            jQuery('.azkaban-upload-button:not(:first)').each(function() {
                var prev_upload_id = jQuery(this).data('upid');
                var new_upload_id = prev_upload_id + 1;
                jQuery(this).attr('data-upid', new_upload_id);
            });
    	}
	}

    // run
    $('#azkaban-popup').livequery(function() {
        azkaban_shortcodes.load();

        $('#azkaban-popup').closest('#TB_window').addClass('azkaban-shortcodes-popup');

        $('#azkaban_video_content').closest('li').hide();

            // activate color picker
            $('.wp-color-picker-field').wpColorPicker({
                change: function(event, ui) {
                    setTimeout(function() {
                        azkaban_shortcodes.loadVals();
                        azkaban_shortcodes.cLoadVals();
                    },
                    1);
                }
            });
    });

    // when insert is clicked
    $('.azkaban-insert').live('click', function() {
        if(window.tinyMCE)
        {
            window.tinyMCE.activeEditor.execCommand('mceInsertContent', false, $('#_azkaban_ushortcode').html());
            tb_remove();
        }
    });

    //tinymce.init(tinyMCEPreInit.mceInit['azkaban_content']);
    //tinymce.execCommand('mceAddControl', true, 'azkaban_content');
    //quicktags({id: 'azkaban_content'});

    // activate upload button
    $('.azkaban-upload-button').live('click', function(e) {
	    e.preventDefault();

        upid = $(this).attr('data-upid');

        if($(this).hasClass('remove-image')) {
            $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('img').attr('src', '').hide();
            $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('input').attr('value', '');
            $('.azkaban-upload-button[data-upid="' + upid + '"]').text('Upload').removeClass('remove-image');

            return;
        }

        var file_frame = wp.media.frames.file_frame = wp.media({
            title: 'Select Image',
            button: {
                text: 'Select Image',
            },
	        frame: 'post',
            multiple: false  // Set to true to allow multiple files to be selected
        });

	    file_frame.open();

        $('.media-menu a:contains(Insert from URL)').remove();

        file_frame.on( 'select', function() {
            var selection = file_frame.state().get('selection');
            selection.map( function( attachment ) {
                attachment = attachment.toJSON();

                $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('img').attr('src', attachment.url).show();
                $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('input').attr('value', attachment.url);

                azkaban_shortcodes.loadVals();
                azkaban_shortcodes.cLoadVals();
            });

            $('.azkaban-upload-button[data-upid="' + upid + '"]').text('Remove').addClass('remove-image');
            $('.media-modal-close').trigger('click');
        });

	    file_frame.on( 'insert', function() {
		    var selection = file_frame.state().get('selection');
		    var size = jQuery('.attachment-display-settings .size').val();

		    selection.map( function( attachment ) {
			    attachment = attachment.toJSON();

			    if(!size) {
				    attachment.url = attachment.url;
			    } else {
				    attachment.url = attachment.sizes[size].url;
			    }

			    $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('img').attr('src', attachment.url).show();
			    $('.azkaban-upload-button[data-upid="' + upid + '"]').parent().find('input').attr('value', attachment.url);

			    azkaban_shortcodes.loadVals();
			    azkaban_shortcodes.cLoadVals();
		    });

		    $('.azkaban-upload-button[data-upid="' + upid + '"]').text('Remove').addClass('remove-image');
		    $('.media-modal-close').trigger('click');
	    });
    });

    // activate iconpicker
    $('.iconpicker i').live('click', function(e) {
        e.preventDefault();

        var iconWithPrefix = $(this).attr('class');
        var fontName = $(this).attr('data-name');

        if($(this).hasClass('active')) {
            $(this).parent().find('.active').removeClass('active');

            $(this).parent().parent().find('input').attr('value', '');
        } else {
            $(this).parent().find('.active').removeClass('active');
            $(this).addClass('active');

            $(this).parent().parent().find('input').attr('value', fontName);
        }

        azkaban_shortcodes.loadVals();
        azkaban_shortcodes.cLoadVals();
    });

    // table shortcode
    $('#azkaban-sc-form-table .azkaban-insert').live('click', function(e) {
        e.stopPropagation();

        var shortcodeType = $('#azkaban_select_shortcode').val();

        if(shortcodeType == 'table') {
            var type = $('#azkaban-sc-form-table #azkaban_type').val();
            var columns = $('#azkaban-sc-form-table #azkaban_columns').val();

            var text = '<div class="azkaban-table table-' + type + '"><table width="100%"><thead><tr>';

            for(var i=0;i<columns;i++) {
                text += '<th>Column ' + (i + 1) + '</th>';
            }

            text += '</tr></thead><tbody>';

            for(var i=0;i<columns;i++) {
                text += '<tr>';
                if(columns >= 1) {
                    text += '<td>Item #' + (i + 1) + '</td>';
                }
                if(columns >= 2) {
                    text += '<td>Description</td>';
                }
                if(columns >= 3) {
                    text += '<td>Discount:</td>';
                }
                if(columns >= 4) {
                    text += '<td>$' + (i + 1) + '.00</td>';
                }
                if(columns >= 5) {
                    text += '<td>$ 0.' + (i + 1) + '0</td>';
                }
                text += '</tr>';
            }

            text += '<tr>';

            if(columns >= 1) {
                text += '<td><strong>All Items</strong></td>';
            }
            if(columns >= 2) {
                text += '<td><strong>Description</strong></td>';
            }
            if(columns >= 3) {
                text += '<td><strong>Your Total:</strong></td>';
            }
            if(columns >= 4) {
                text += '<td><strong>$10.00</strong></td>';
            }
            if(columns >= 4) {
                text += '<td><strong>Tax</strong></td>';
            }
            text += '</tr>';
            text += '</tbody></table></div>';

            if(window.tinyMCE)
            {
                window.tinyMCE.activeEditor.execCommand('mceInsertContent', false, text);
                tb_remove();
            }
        }
    });

    // slider shortcode
    $('#azkaban_slider_type').live('change', function(e) {
        e.preventDefault();

        var type = $(this).val();
        if(type == 'video') {
            $(this).parents('ul').find('#azkaban_image_content, #azkaban_image_url, #azkaban_image_target, #azkaban_image_lightbox').closest('li').hide();
            $(this).parents('ul').find('#azkaban_video_content').closest('li').show();

            $('#_azkaban_cshortcode').text('[slide type="{{slider_type}}"]{{video_content}}[/slide]');
        }

        if(type == 'image') {
            $(this).parents('ul').find('#azkaban_image_content, #azkaban_image_url, #azkaban_image_target, #azkaban_image_lightbox').closest('li').show();
            $(this).parents('ul').find('#azkaban_video_content').closest('li').hide();

            $('#_azkaban_cshortcode').text('[slide type="{{slider_type}}" link="{{image_url}}" linktarget="{{image_target}}" lightbox="{{image_lightbox}}"]{{image_content}}[/slide]');
        }
    });

    $('.azkaban-add-video-shortcode').live('click', function(e) {
        e.preventDefault();

        var shortcode = $(this).attr('href');
        var content = $(this).parents('ul').find('#azkaban_video_content');

        content.val(content.val() + shortcode);
        azkaban_shortcodes.cLoadVals();
    });

    $('#azkaban-popup textarea').live('focus', function() {
        var text = $(this).val();

        if(text == 'Your Content Goes Here') {
            $(this).val('');
        }
    });

    $('.azkaban-gallery-button').live('click', function(e) {
	    var gallery_file_frame;

        e.preventDefault();

	    alert('To add images to this post or page for attachments layout, navigate to "Upload Files" tab in media manager and upload new images.');

        gallery_file_frame = wp.media.frames.gallery_file_frame = wp.media({
            title: 'Attach Images to Post/Page',
            button: {
                text: 'Go Back to Shortcode',
            },
            frame: 'post',
            multiple: true  // Set to true to allow multiple files to be selected
        });

	    gallery_file_frame.open();

        $('.media-menu a:contains(Insert from URL)').remove();
        
        $('.media-menu-item:contains("Upload Files")').trigger('click');

        gallery_file_frame.on( 'select', function() {
            $('.media-modal-close').trigger('click');

            azkaban_shortcodes.loadVals();
            azkaban_shortcodes.cLoadVals();
        });
    });
});