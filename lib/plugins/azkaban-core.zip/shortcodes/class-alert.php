<?php

class AX_Alert {

    private $alert_class;
    private $icon_class;
    public static $args;

    /**
     * Initiate the shortcode
     */
    public function __construct() {

        add_filter( 'azkaban_attr_alert-shortcode', array( $this, 'attr' ) );
        add_filter( 'azkaban_attr_alert-shortcode-icon', array( $this, 'icon_attr' ) );
        add_shortcode( 'alert', array( $this, 'render' ) );

    }

    /**
     * Render the shortcode
     * @param  array $args     Shortcode paramters
     * @param  string $content Content between shortcode
     * @return string          HTML output
     */
    function render( $args, $content = '') {

        $defaults = AzkabanCore_Plugin::set_shortcode_defaults(
        	array(
				'class'               	=> '',
				'id'                 	=> '',
				'accent_color'			=> '',
				'background_color'		=> '',
				'border_size'			=> '',
				'box_shadow'			=> 'no',
				'icon'					=> '',
				'type'                	=> 'general',
        	), $args
        );

        extract( $defaults );

        self::$args = $defaults;

        switch( $args['type'] ) {

            case 'general':
                $this->alert_class = 'info';
                if( ! $icon || $icon != 'none' ) {
                	self::$args['icon'] = $icon = 'fa-info-circle';
                }
                break;
            case 'error':
                $this->alert_class = 'danger';
                if( ! $icon || $icon != 'none' ) {
                	self::$args['icon'] = $icon = 'fa-exclamation-triangle';
                }                
                break;
            case 'success':
                $this->alert_class = 'success';
                if( ! $icon || $icon != 'none' ) {
                	self::$args['icon'] = $icon = 'fa-check-circle';
                }                
                break;
            case 'notice':
                $this->alert_class = 'warning';
                if( ! $icon || $icon != 'none' ) {
                	self::$args['icon'] = $icon = 'fa-lg fa-cog';
                }                
                break;
            case 'blank':
                $this->alert_class = 'blank';
                break;
            case 'custom':
                $this->alert_class = 'custom';
                break;
        }

        $html = sprintf( '<div %s>', AzkabanCore_Plugin::attributes( 'alert-shortcode' ) ) . "\n";
        if( $icon && $icon != 'none' ) {
        	$html .= sprintf( '<span %s><i %s></i></span>', AzkabanCore_Plugin::attributes( 'alert-icon' ), AzkabanCore_Plugin::attributes( 'alert-shortcode-icon' ) );
        }
        $html .= do_shortcode( $content );
        $html .= '</div>' . "\n";

        return $html;

    }

    function attr() {

		$attr = array();

        $attr['class'] = sprintf( 'az-alert alert %s alert-dismissable alert-%s', self::$args['type'], $this->alert_class );
        
        if( self::$args['box_shadow'] == 'yes' ) {
        	$attr['class'] .= ' alert-shadow';
        }

        if( $this->alert_class == 'custom' ) {
        	$attr['style'] = sprintf( 'background-color:%s;color:%s;border-color:%s;border-width:%s;', self::$args['background_color'],
        							  self::$args['accent_color'], self::$args['accent_color'], self::$args['border_size'] );
        }

        if( self::$args['class'] ) {
            $attr['class'] .= ' ' . self::$args['class'];
        }

        if( self::$args['id'] ) {
            $attr['id'] = self::$args['id'];
        }

        return $attr;

    }

    function icon_attr() {

    	$attr = array();

        $attr['class'] = sprintf( 'fa fa-lg %s', AzkabanCore_Plugin::font_awesome_name_handler( self::$args['icon'] ) );

        return $attr;

    }

}

new AX_Alert();